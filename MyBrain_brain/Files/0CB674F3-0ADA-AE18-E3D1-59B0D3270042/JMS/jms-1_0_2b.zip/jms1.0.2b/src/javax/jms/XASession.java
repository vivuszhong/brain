/*
 * @(#)XASession.java	1.16 01/02/15
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

import javax.transaction.xa.XAResource;

/** The <CODE>XASession</CODE> interface extends the capability of 
  * <CODE>Session</CODE> by adding access to a JMS provider's support for the
  * Java Transaction API (JTA) (optional). This support takes the form of a 
  * <CODE>javax.transaction.xa.XAResource</CODE> object. The functionality of 
  * this object closely resembles that defined by the standard X/Open XA 
  * Resource interface.
  *
  * <P>An application server controls the transactional assignment of an 
  * <CODE>XASession</CODE> by obtaining its <CODE>XAResource</CODE>. It uses 
  * the <CODE>XAResource</CODE> to assign the session to a transaction, prepare 
  * and commit work on the transaction, and so on.
  *
  * <P>An <CODE>XAResource</CODE> provides some fairly sophisticated facilities 
  * for interleaving work on multiple transactions, recovering a list of 
  * transactions in progress, and so on. A JTA aware JMS provider must fully 
  * implement this functionality. This could be done by using the services 
  * of a database that supports XA, or a JMS provider may choose to implement 
  * this functionality from scratch.
  *
  * <P>A client of the application server is given what it thinks is a 
  * regular JMS <CODE>Session</CODE>. Behind the scenes, the application server 
  * controls the transaction management of the underlying 
  * <CODE>XASession</CODE>.
  * 
  * @version     1.0 - 13 August 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.Session
  */ 
 
public interface XASession extends Session {

    /** Returns an XA resource to the caller.
      *
      * @return an XA resource to the caller
      */

     XAResource
     getXAResource();

    /** Indicates whether the session is in transacted mode.
      *  
      * @return true
      *  
      * @exception JMSException if the JMS provider fails to return the 
      *                         transaction mode due to some internal error.
      */ 

    boolean
    getTransacted() throws JMSException;


    /** Throws a <CODE>TransactionInProgressException</CODE>, since it should 
      * not be called for an <CODE>XASession</CODE> object.
      *
      * @exception TransactionInProgressException if the method is called on 
      *                         an <CODE>XASession</CODE>.
      *                                     
      */

    void
    commit() throws JMSException;


    /** Throws a <CODE>TransactionInProgressException</CODE>, since it should 
      * not be called for an <CODE>XASession</CODE> object.
      *
      * @exception TransactionInProgressException if the method is called on 
      *                         an <CODE>XASession</CODE>.
      *                                     
      */

    void
    rollback() throws JMSException;
}
