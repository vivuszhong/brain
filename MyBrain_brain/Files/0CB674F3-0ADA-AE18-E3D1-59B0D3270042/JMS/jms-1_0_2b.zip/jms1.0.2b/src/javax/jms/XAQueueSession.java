/*
 * @(#)XAQueueSession.java	1.9 01/02/15
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** An <CODE>XAQueueSession</CODE> provides a regular <CODE>QueueSession</CODE>,
  * which can be used to
  * create <CODE>QueueReceiver</CODE>, <CODE>QueueSender</CODE>, and 
  *<CODE>QueueBrowser</CODE> objects (optional).
  *
  * @version     1.0 - 13 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.XASession
  */

public interface XAQueueSession extends XASession {

    /** Gets the queue session associated with this <CODE>XAQueueSession</CODE>.
      *  
      * @return the queue session object
      *  
      * @exception JMSException if an internal error occurs.
      */ 
 
    QueueSession
    getQueueSession() throws JMSException;
}
