package net.glxn.qrgen.image;

public enum ImageType {
    JPG, GIF, PNG
}
