package demo;

import com.barcodelib.barcode.PDF417;


public class PDF417Demo
{
    public static void main(String[] args) throws Exception
    {
        PDF417 barcode = new PDF417();
        barcode.setProcessTilde(true);
        barcode.setData("12345678 abcdefgh 12345678 abcdefgh 12345678 abcdefgh 12345678\n" +
                "abcdefgh12345678 abcdefgh 12345678 abcdefgh12345678 abcdefgh 12345678\n" +
                "abcdefgh\n" +
                "12345678 abcdefgh 12345678 abcdefgh 12345678 abcdefgh 12345678 abcdefgh\n" +
                "12345678 abcdefgh 12345678 abcdefgh 12345678 abcdefgh 12345678 abcdefgh\n" +
                "12345678 abcdefgh 12345678 abcdefgh 12345678 abcdefgh 12345678 abcdefgh\n" +
                "12345678 abcdefgh 12345678 abcdefgh 12345678 abcdefgh 12345678 abcdefgh");

        barcode.setEcl(PDF417.ECL_2);
        // 3 - 90
        barcode.setRowCount(40);
        // 1 - 30
        barcode.setColumnCount(8);
        barcode.setDataMode(PDF417.MODE_AUTO);

        barcode.setUOM(0);
        barcode.setX(2);
        barcode.setBarRatio(3);
        barcode.setLeftMargin(10);
        barcode.setRightMargin(10);
        barcode.setTopMargin(10);
        barcode.setBottomMargin(10);
        barcode.setResolution(72);
        barcode.setRotate(0);

        barcode.renderBarcode("C://pdf417.gif");
    }
}
